// Service Worker — Smart RV (mise en cache pour fonctionnement 100% hors-ligne après la première
// ouverture). Stratégie : cache-first pour tout, avec repli réseau qui alimente le cache au passage.
// Les données de l'app (compteurs, tournée, GPS) restent dans IndexedDB, gérées par la page elle-même,
// et ne sont pas concernées par ce fichier.

const CACHE_NAME = 'smartrv-offline-v1';

const CORE_ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  'https://cdn.tailwindcss.com',
  'https://cdn.jsdelivr.net/npm/xlsx-js-style@1.2.0/dist/xlsx.bundle.js',
  'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return Promise.all(
        CORE_ASSETS.map((url) =>
          cache.add(new Request(url, { mode: 'no-cors' })).catch((err) => {
            // Un seul fichier externe indisponible ne doit pas empêcher l'installation du reste.
            console.warn('SW: échec de mise en cache de', url, err);
          })
        )
      );
    }).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return; // ne jamais intercepter les envois de données

  event.respondWith(
    caches.match(req).then((cached) => {
      // Réseau en tâche de fond pour garder le cache à jour quand une connexion existe,
      // sans jamais faire attendre l'utilisateur : on répond immédiatement depuis le cache si présent.
      const network = fetch(req)
        .then((res) => {
          if (res && (res.ok || res.type === 'opaque')) {
            const resClone = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone)).catch(() => {});
          }
          return res;
        })
        .catch(() => null);

      return cached || network || fetch(req);
    })
  );
});
